<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
$page_title = 'কার্ট';

// কার্ট আপডেট হ্যান্ডল (qty পরিবর্তন / রিমুভ) - নরমাল ফর্ম পোস্ট (JS ছাড়াই কাজ করে)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        foreach ($_POST['qty'] as $pid => $qty) {
            $qty = (int)$qty;
            if ($qty <= 0) {
                unset($_SESSION['cart'][$pid]);
            } else {
                $_SESSION['cart'][$pid] = $qty;
            }
        }
    } elseif (isset($_POST['remove_id'])) {
        unset($_SESSION['cart'][(int)$_POST['remove_id']]);
    }
    redirect('cart.php');
}

$cart = get_cart();
$items = [];
$total = 0;

if (!empty($cart)) {
    $ids = array_map('intval', array_keys($cart));
    $in = implode(',', $ids);
    $result = $conn->query("SELECT * FROM products WHERE id IN ($in)");
    while ($p = $result->fetch_assoc()) {
        $qty = $cart[$p['id']];
        $subtotal = $qty * $p['price'];
        $total += $subtotal;
        $items[] = ['product' => $p, 'qty' => $qty, 'subtotal' => $subtotal];
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container">
  <div class="section-title"><span class="leaf"></span><h2>আপনার কার্ট</h2></div>

  <?php if (empty($items)): ?>
    <div class="empty-box">
      🧺 আপনার কার্ট খালি।<br><br>
      <a href="index.php" class="btn">পণ্য দেখুন</a>
    </div>
  <?php else: ?>
  <form method="post">
    <table class="cart-table">
      <thead>
        <tr><th>পণ্য</th><th>দাম</th><th>পরিমাণ</th><th>সাবটোটাল</th><th></th></tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): $p = $item['product']; ?>
        <tr>
          <td class="p-name"><img src="<?php echo product_image_url($p['image']); ?>" alt=""><?php echo e($p['name']); ?></td>
          <td><?php echo taka($p['price']); ?> / <?php echo e($p['unit']); ?></td>
          <td><input type="number" name="qty[<?php echo $p['id']; ?>]" value="<?php echo $item['qty']; ?>" min="0" max="<?php echo (int)$p['stock_qty']; ?>" style="width:70px; padding:6px; border:1.5px solid var(--border); border-radius:8px;"></td>
          <td><?php echo taka($item['subtotal']); ?></td>
          <td><button type="submit" name="remove_id" value="<?php echo $p['id']; ?>" class="remove-link" style="background:none;border:none;">✕ বাদ দিন</button></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <button type="submit" name="update" class="btn btn-outline">পরিমাণ আপডেট করুন</button>
  </form>

  <div class="cart-summary">
    <div class="row"><span>মোট পণ্য</span><span><?php echo array_sum($cart); ?></span></div>
    <div class="row total"><span>সর্বমোট</span><span><?php echo taka($total); ?></span></div>
    <a href="checkout.php" class="btn" style="display:block; text-align:center; margin-top:14px;">অর্ডার সম্পন্ন করুন</a>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
