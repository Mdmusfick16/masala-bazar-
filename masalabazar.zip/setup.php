<?php
require_once __DIR__ . '/config.php';

$msg = '';
$check = $conn->query("SELECT COUNT(*) as c FROM admins");
$row = $check->fetch_assoc();

if ($row['c'] > 0) {
    $msg = 'একটি এডমিন একাউন্ট ইতিমধ্যে আছে। সুরক্ষার জন্য এই setup.php ফাইলটি এখনই ডিলিট করে দিন।';
} else {
    $username = 'admin';
    $password = 'admin123';
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
    $stmt->bind_param('ss', $username, $hash);
    $stmt->execute();
    $msg = "ডিফল্ট এডমিন একাউন্ট তৈরি হয়েছে!<br><br><b>Username:</b> admin<br><b>Password:</b> admin123<br><br>⚠️ এখনই লগইন করে পাসওয়ার্ড পরিবর্তন করুন এবং তারপর সুরক্ষার জন্য এই setup.php ফাইলটি সার্ভার থেকে ডিলিট করে দিন।";
}
?>
<!DOCTYPE html>
<html lang="bn"><head><meta charset="UTF-8"><title>Setup</title>
<style>body{font-family:sans-serif;max-width:520px;margin:80px auto;background:#EAF5EE;padding:30px;border-radius:14px;line-height:1.7;} a{color:#0E4B2E;font-weight:bold;}</style>
</head>
<body>
<h2>🛒 MasalaBazar Setup</h2>
<p><?php echo $msg; ?></p>
<p><a href="admin/login.php">→ এডমিন প্যানেলে লগইন করুন</a></p>
</body></html>
