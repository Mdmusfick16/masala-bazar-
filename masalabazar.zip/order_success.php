<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
$page_title = 'অর্ডার সফল';

$order_id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM orders WHERE id=?");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    redirect('index.php');
}

require_once __DIR__ . '/includes/header.php';
?>
<div class="container">
  <div class="success-box">
    <div class="icon">✓</div>
    <h2>ধন্যবাদ, <?php echo e($order['customer_name']); ?>!</h2>
    <p>আপনার অর্ডার #<?php echo $order['id']; ?> সফলভাবে গ্রহণ করা হয়েছে।<br>
    আমরা শীঘ্রই আপনার দেওয়া <?php echo e($order['phone']); ?> নম্বরে যোগাযোগ করব।</p>
    <p style="font-weight:700; font-size:20px; color:var(--dark-green);">সর্বমোট: <?php echo taka($order['total_amount']); ?></p>
    <a href="index.php" class="btn">আরও পণ্য দেখুন</a>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
