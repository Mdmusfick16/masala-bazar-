<?php
/**
 * MasalaBazar - কনফিগারেশন ফাইল
 * নিচের ডাটাবেস তথ্যগুলো আপনার cPanel এর তথ্য দিয়ে পরিবর্তন করুন
 */

session_start();
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
date_default_timezone_set('Asia/Dhaka');

// ================= ডাটাবেস তথ্য (এখানে পরিবর্তন করুন) =================
define('DB_HOST', 'localhost');
define('DB_USER', 'your_cpanel_db_username');
define('DB_PASS', 'your_cpanel_db_password');
define('DB_NAME', 'your_cpanel_db_name');
// =======================================================================

define('SITE_NAME', 'MasalaBazar');

// সাইট যদি সাব-ফোল্ডারে থাকে (যেমন: yourdomain.com/shop/) তাহলে নিচে '/shop/' লিখুন, নাহলে '/' রাখুন
define('BASE_URL', '/');

define('UPLOAD_PRODUCT_DIR', __DIR__ . '/uploads/products/');
define('UPLOAD_BANNER_DIR', __DIR__ . '/uploads/banners/');
define('UPLOAD_PRODUCT_URL', BASE_URL . 'uploads/products/');
define('UPLOAD_BANNER_URL', BASE_URL . 'uploads/banners/');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die('ডাটাবেস কানেকশন ব্যর্থ হয়েছে। config.php ফাইলে ডাটাবেস তথ্য ঠিক আছে কিনা দেখুন। Error: ' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');
