<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

$page_title = 'হোম';

// ব্যানার/পোস্টার লোড
$banners = $conn->query("SELECT * FROM banners ORDER BY sort_order ASC, id DESC");

// ক্যাটাগরি লোড
$categories = $conn->query("SELECT * FROM categories ORDER BY name ASC");

$cat_id = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$q = trim($_GET['q'] ?? '');

$sql = "SELECT * FROM products WHERE status='active'";
$params = [];
$types = '';
if ($cat_id > 0) {
    $sql .= " AND category_id = ?";
    $params[] = $cat_id;
    $types .= 'i';
}
if ($q !== '') {
    $sql .= " AND name LIKE ?";
    $params[] = '%' . $q . '%';
    $types .= 's';
}
$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$products = $stmt->get_result();

require_once __DIR__ . '/includes/header.php';
?>

<?php if ($banners && $banners->num_rows > 0): ?>
<div class="hero-slider">
  <div class="hero-track" id="heroTrack">
    <?php $i = 0; while ($b = $banners->fetch_assoc()): $i++; ?>
      <div class="hero-slide">
        <img src="<?php echo banner_image_url($b['image']); ?>" alt="<?php echo e($b['title']); ?>">
        <?php if (!empty($b['title'])): ?><div class="cap"><?php echo e($b['title']); ?></div><?php endif; ?>
      </div>
    <?php endwhile; ?>
  </div>
  <div class="hero-dots" id="heroDots"></div>
</div>
<?php endif; ?>

<div class="container">
  <div class="chips">
    <a href="index.php" class="chip <?php echo $cat_id === 0 ? 'active' : ''; ?>">সব পণ্য</a>
    <?php while ($c = $categories->fetch_assoc()): ?>
      <a href="index.php?cat=<?php echo $c['id']; ?>" class="chip <?php echo $cat_id === (int)$c['id'] ? 'active' : ''; ?>"><?php echo e($c['name']); ?></a>
    <?php endwhile; ?>
  </div>

  <div class="section-title"><span class="leaf"></span><h2><?php echo $q !== '' ? 'অনুসন্ধানের ফলাফল: ' . e($q) : 'সকল পণ্য'; ?></h2></div>

  <?php if ($products->num_rows === 0): ?>
    <div class="empty-box">😕 কোনো পণ্য পাওয়া যায়নি।</div>
  <?php else: ?>
  <div class="grid">
    <?php while ($p = $products->fetch_assoc()): ?>
      <div class="card">
        <div class="thumb">
          <?php if ((int)$p['stock_qty'] <= 0): ?><span class="stock-badge">স্টক নেই</span><?php endif; ?>
          <img src="<?php echo product_image_url($p['image']); ?>" alt="<?php echo e($p['name']); ?>">
        </div>
        <div class="body">
          <div class="name"><?php echo e($p['name']); ?></div>
          <div class="unit">প্রতি <?php echo e($p['unit']); ?></div>
          <div class="price-row">
            <span class="price"><?php echo taka($p['price']); ?></span>
          </div>
        </div>
        <?php if ((int)$p['stock_qty'] > 0): ?>
        <form class="add-to-cart-form" data-id="<?php echo $p['id']; ?>">
          <div class="qty-box">
            <button type="button" class="qty-minus">-</button>
            <input type="number" class="qty-input" value="1" min="1" max="<?php echo (int)$p['stock_qty']; ?>">
            <button type="button" class="qty-plus">+</button>
          </div>
          <button type="submit" class="add-btn">কার্টে যোগ করুন</button>
        </form>
        <?php else: ?>
        <div style="padding:0 14px 14px;"><button class="add-btn" disabled style="background:#ccc;">স্টক নেই</button></div>
        <?php endif; ?>
      </div>
    <?php endwhile; ?>
  </div>
  <?php endif; ?>
</div>

<div class="toast" id="toast">✅ কার্টে যোগ হয়েছে</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
<script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
