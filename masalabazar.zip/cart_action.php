<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_POST['action'] ?? '';
$product_id = (int)($_POST['product_id'] ?? 0);
$qty = max(1, (int)($_POST['qty'] ?? 1));

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if ($action === 'add' && $product_id > 0) {
    $stmt = $conn->prepare("SELECT stock_qty FROM products WHERE id=? AND status='active'");
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    if (!$res) {
        echo json_encode(['ok' => false, 'message' => 'পণ্যটি পাওয়া যায়নি']);
        exit;
    }
    $current = $_SESSION['cart'][$product_id] ?? 0;
    $new_qty = min($current + $qty, (int)$res['stock_qty']);
    $_SESSION['cart'][$product_id] = $new_qty;
    echo json_encode(['ok' => true, 'message' => 'কার্টে যোগ হয়েছে', 'cart_count' => get_cart_count()]);
    exit;
}

if ($action === 'update' && $product_id > 0) {
    if ($qty <= 0) {
        unset($_SESSION['cart'][$product_id]);
    } else {
        $_SESSION['cart'][$product_id] = $qty;
    }
    echo json_encode(['ok' => true, 'cart_count' => get_cart_count()]);
    exit;
}

if ($action === 'remove' && $product_id > 0) {
    unset($_SESSION['cart'][$product_id]);
    echo json_encode(['ok' => true, 'cart_count' => get_cart_count()]);
    exit;
}

echo json_encode(['ok' => false, 'message' => 'ভুল রিকোয়েস্ট']);
