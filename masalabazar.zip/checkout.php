<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
$page_title = 'চেকআউট';

$cart = get_cart();
if (empty($cart)) {
    redirect('cart.php');
}

$ids = array_map('intval', array_keys($cart));
$in = implode(',', $ids);
$result = $conn->query("SELECT * FROM products WHERE id IN ($in)");
$items = [];
$total = 0;
while ($p = $result->fetch_assoc()) {
    $qty = min($cart[$p['id']], (int)$p['stock_qty']);
    if ($qty <= 0) continue;
    $subtotal = $qty * $p['price'];
    $total += $subtotal;
    $items[] = ['product' => $p, 'qty' => $qty, 'subtotal' => $subtotal];
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $note = trim($_POST['note'] ?? '');

    if ($name === '' || $phone === '' || $address === '') {
        $error = 'দয়া করে নাম, মোবাইল নম্বর এবং ঠিকানা পূরণ করুন।';
    } elseif (!preg_match('/^01[0-9]{9}$/', $phone)) {
        $error = 'সঠিক মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।';
    } elseif (empty($items)) {
        $error = 'আপনার কার্টে কোনো পণ্য নেই।';
    } else {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("INSERT INTO orders (customer_name, phone, address, note, total_amount, status) VALUES (?,?,?,?,?, 'pending')");
            $stmt->bind_param('ssssd', $name, $phone, $address, $note, $total);
            $stmt->execute();
            $order_id = $stmt->insert_id;

            $stmt2 = $conn->prepare("INSERT INTO order_items (order_id, product_id, product_name, price, qty, subtotal) VALUES (?,?,?,?,?,?)");
            foreach ($items as $item) {
                $p = $item['product'];
                $stmt2->bind_param('iisdid', $order_id, $p['id'], $p['name'], $p['price'], $item['qty'], $item['subtotal']);
                $stmt2->execute();

                // স্টক কমানো
                $conn->query("UPDATE products SET stock_qty = stock_qty - " . (int)$item['qty'] . " WHERE id = " . (int)$p['id']);
            }
            $conn->commit();
            unset($_SESSION['cart']);
            redirect('order_success.php?id=' . $order_id);
        } catch (Exception $e) {
            $conn->rollback();
            $error = 'দুঃখিত, অর্ডার সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।';
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container">
  <div class="section-title"><span class="leaf"></span><h2>অর্ডার তথ্য দিন</h2></div>

  <?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>

  <div class="checkout-wrap">
    <form class="form-box" method="post">
      <label>আপনার নাম *</label>
      <input type="text" name="name" required value="<?php echo e($_POST['name'] ?? ''); ?>" placeholder="যেমন: করিম আহমেদ">

      <label>মোবাইল নম্বর *</label>
      <input type="text" name="phone" required value="<?php echo e($_POST['phone'] ?? ''); ?>" placeholder="017XXXXXXXX">

      <label>সম্পূর্ণ ঠিকানা *</label>
      <textarea name="address" rows="3" required placeholder="বাড়ি/ফ্ল্যাট নং, রোড, এলাকা, থানা, জেলা"><?php echo e($_POST['address'] ?? ''); ?></textarea>

      <label>বিশেষ নির্দেশনা (ঐচ্ছিক)</label>
      <textarea name="note" rows="2" placeholder="যেমন: বিকেলে ডেলিভারি দিন"><?php echo e($_POST['note'] ?? ''); ?></textarea>

      <button type="submit" class="btn" style="width:100%; margin-top:18px;">অর্ডার কনফার্ম করুন</button>
      <p style="color:var(--muted); font-size:13px; margin-top:10px;">💰 পেমেন্ট মেথড: ক্যাশ অন ডেলিভারি</p>
    </form>

    <div class="form-box">
      <h3 style="margin-top:0;">অর্ডার সামারি</h3>
      <?php foreach ($items as $item): $p = $item['product']; ?>
        <div class="order-mini-row">
          <span><?php echo e($p['name']); ?> × <?php echo $item['qty']; ?></span>
          <span><?php echo taka($item['subtotal']); ?></span>
        </div>
      <?php endforeach; ?>
      <div class="cart-summary" style="margin:16px 0 0; max-width:100%;">
        <div class="row total"><span>সর্বমোট</span><span><?php echo taka($total); ?></span></div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
