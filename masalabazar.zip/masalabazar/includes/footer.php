<footer class="site-footer">
  <div class="container">
    <div>
      <h4>MasalaBazar</h4>
      <p style="max-width:280px;">আপনার বাসার নিত্যপ্রয়োজনীয় মুদি মালামাল এখন হাতের নাগালে। মানসম্মত পণ্য, সঠিক দাম, দ্রুত ডেলিভারি।</p>
    </div>
    <div>
      <h4>যোগাযোগ</h4>
      <p>📞 ০১৭XXXXXXXX<br>📍 ঢাকা, বাংলাদেশ</p>
    </div>
    <div>
      <h4>দ্রুত লিংক</h4>
      <p><a href="<?php echo BASE_URL; ?>index.php">হোম</a><br><a href="<?php echo BASE_URL; ?>cart.php">কার্ট</a></p>
    </div>
  </div>
  <div class="bottom">&copy; <?php echo date('Y'); ?> MasalaBazar. সর্বস্বত্ব সংরক্ষিত।</div>
</footer>
</body>
</html>
