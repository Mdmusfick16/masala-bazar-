<?php
require_once __DIR__ . '/functions.php';
$cart_count = get_cart_count();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? e($page_title) . ' - ' . SITE_NAME : SITE_NAME . ' | নিত্যপ্রয়োজনীয় মুদি বাজার'; ?></title>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
</head>
<body>

<div class="topbar">
  <div class="container">
    <span>🥬 আজকের বাজার থেকে সতেজ পণ্য, সরাসরি আপনার বাসায়</span>
    <span>📞 অর্ডার হেল্পলাইন: ০১৭XXXXXXXX</span>
  </div>
</div>

<header class="site-header">
  <div class="container">
    <a href="<?php echo BASE_URL; ?>index.php" class="brand">🛒 Masala<span class="tag">Bazar</span></a>
    <form class="search-form" action="<?php echo BASE_URL; ?>index.php" method="get">
      <input type="text" name="q" placeholder="পণ্য খুঁজুন... যেমন: চাল, তেল, মশলা" value="<?php echo e($_GET['q'] ?? ''); ?>">
      <button type="submit">খুঁজুন</button>
    </form>
    <a href="<?php echo BASE_URL; ?>cart.php" class="cart-pill">🧺 কার্ট <span class="count"><?php echo $cart_count; ?></span></a>
  </div>
</header>
