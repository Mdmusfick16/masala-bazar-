<?php
function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function taka($amount) {
    return '৳' . number_format((float)$amount, 2);
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function is_logged_in() {
    return isset($_SESSION['admin_id']);
}

function require_login() {
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

function product_image_url($image) {
    if (!empty($image) && file_exists(UPLOAD_PRODUCT_DIR . $image)) {
        return UPLOAD_PRODUCT_URL . $image;
    }
    return BASE_URL . 'assets/img/no-image.svg';
}

function banner_image_url($image) {
    return UPLOAD_BANNER_URL . $image;
}

function get_cart() {
    return $_SESSION['cart'] ?? [];
}

function get_cart_count() {
    $count = 0;
    foreach (get_cart() as $qty) {
        $count += (int)$qty;
    }
    return $count;
}

// একটি ছবি আপলোড করে ফাইলের নাম রিটার্ন করে, ব্যর্থ হলে false
function handle_image_upload($file_field, $target_dir) {
    if (empty($_FILES[$file_field]['name'])) {
        return null; // কোনো ছবি দেওয়া হয়নি
    }
    $file = $_FILES[$file_field];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!array_key_exists($ext, $allowed)) {
        return false;
    }
    if ($file['size'] > 5 * 1024 * 1024) { // 5MB সীমা
        return false;
    }
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }
    $new_name = uniqid('img_', true) . '.' . $ext;
    if (move_uploaded_file($file['tmp_name'], $target_dir . $new_name)) {
        return $new_name;
    }
    return false;
}

function delete_image($filename, $dir) {
    if (!empty($filename) && file_exists($dir . $filename)) {
        @unlink($dir . $filename);
    }
}
