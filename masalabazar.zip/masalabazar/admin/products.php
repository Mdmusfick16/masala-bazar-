<?php
$page_title = 'পণ্য তালিকা';
require_once __DIR__ . '/includes/header.php';

$products = $conn->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC");
?>

<div class="topbar">
  <h1>পণ্য তালিকা</h1>
  <a href="product_form.php" class="btn">+ নতুন পণ্য যুক্ত করুন</a>
</div>

<?php if (isset($_GET['deleted'])): ?><div class="alert alert-success">পণ্যটি মুছে ফেলা হয়েছে।</div><?php endif; ?>
<?php if (isset($_GET['saved'])): ?><div class="alert alert-success">পণ্যটি সফলভাবে সংরক্ষণ করা হয়েছে।</div><?php endif; ?>

<div class="card-box">
  <table>
    <thead><tr><th>ছবি</th><th>নাম</th><th>ক্যাটাগরি</th><th>দাম</th><th>স্টক</th><th>স্ট্যাটাস</th><th></th></tr></thead>
    <tbody>
      <?php if ($products->num_rows === 0): ?>
        <tr><td colspan="7" style="text-align:center; padding:30px; color:#5E6D64;">কোনো পণ্য যুক্ত করা হয়নি। "নতুন পণ্য যুক্ত করুন" বাটনে ক্লিক করুন।</td></tr>
      <?php endif; ?>
      <?php while ($p = $products->fetch_assoc()): ?>
      <tr>
        <td><img src="<?php echo product_image_url($p['image']); ?>" class="thumb"></td>
        <td><?php echo e($p['name']); ?></td>
        <td><?php echo e($p['cat_name'] ?? '—'); ?></td>
        <td><?php echo taka($p['price']); ?> / <?php echo e($p['unit']); ?></td>
        <td><?php echo (int)$p['stock_qty']; ?></td>
        <td><span class="badge <?php echo $p['status']==='active'?'badge-completed':'badge-cancelled'; ?>"><?php echo $p['status']==='active'?'একটিভ':'ইনএকটিভ'; ?></span></td>
        <td style="white-space:nowrap;">
          <a href="product_form.php?id=<?php echo $p['id']; ?>" class="btn btn-outline" style="padding:6px 12px;">এডিট</a>
          <a href="product_delete.php?id=<?php echo $p['id']; ?>" class="btn btn-danger" style="padding:6px 12px;" onclick="return confirm('আপনি কি নিশ্চিত এই পণ্যটি ডিলিট করতে চান?');">ডিলিট</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
