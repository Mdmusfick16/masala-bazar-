<?php
$page_title = 'ড্যাশবোর্ড';
require_once __DIR__ . '/includes/header.php';

$total_products = $conn->query("SELECT COUNT(*) c FROM products")->fetch_assoc()['c'];
$total_orders = $conn->query("SELECT COUNT(*) c FROM orders")->fetch_assoc()['c'];
$pending_orders = $conn->query("SELECT COUNT(*) c FROM orders WHERE status='pending'")->fetch_assoc()['c'];
$total_sales = $conn->query("SELECT SUM(total_amount) s FROM orders WHERE status != 'cancelled'")->fetch_assoc()['s'] ?? 0;

$recent = $conn->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 8");
?>

<div class="topbar"><h1>ড্যাশবোর্ড</h1></div>

<div class="stat-grid">
  <div class="stat-card"><div class="num"><?php echo $total_orders; ?></div><div class="label">মোট অর্ডার</div></div>
  <div class="stat-card"><div class="num"><?php echo $pending_orders; ?></div><div class="label">পেন্ডিং অর্ডার</div></div>
  <div class="stat-card"><div class="num"><?php echo $total_products; ?></div><div class="label">মোট পণ্য</div></div>
  <div class="stat-card"><div class="num"><?php echo taka($total_sales); ?></div><div class="label">মোট বিক্রি</div></div>
</div>

<div class="card-box">
  <h3 style="margin-top:0;">সাম্প্রতিক অর্ডার</h3>
  <table>
    <thead><tr><th>#</th><th>কাস্টমার</th><th>ফোন</th><th>মোট</th><th>স্ট্যাটাস</th><th>তারিখ</th><th></th></tr></thead>
    <tbody>
      <?php if ($recent->num_rows === 0): ?>
        <tr><td colspan="7" style="text-align:center; color:#5E6D64; padding:30px;">এখনো কোনো অর্ডার আসেনি।</td></tr>
      <?php endif; ?>
      <?php while ($o = $recent->fetch_assoc()): ?>
      <tr>
        <td>#<?php echo $o['id']; ?></td>
        <td><?php echo e($o['customer_name']); ?></td>
        <td><?php echo e($o['phone']); ?></td>
        <td><?php echo taka($o['total_amount']); ?></td>
        <td><span class="badge badge-<?php echo $o['status']; ?>"><?php echo e($o['status']); ?></span></td>
        <td><?php echo date('d M, h:i A', strtotime($o['created_at'])); ?></td>
        <td><a href="order_detail.php?id=<?php echo $o['id']; ?>" class="btn btn-outline">দেখুন</a></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
