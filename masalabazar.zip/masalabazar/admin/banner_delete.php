<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $stmt = $conn->prepare("SELECT image FROM banners WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $b = $stmt->get_result()->fetch_assoc();
    if ($b) {
        delete_image($b['image'], UPLOAD_BANNER_DIR);
        $del = $conn->prepare("DELETE FROM banners WHERE id=?");
        $del->bind_param('i', $id);
        $del->execute();
    }
}
redirect('banners.php?deleted=1');
