<?php
$page_title = 'পোস্টার/ব্যানার';
require_once __DIR__ . '/includes/header.php';

$banners = $conn->query("SELECT * FROM banners ORDER BY sort_order ASC, id DESC");
?>

<div class="topbar">
  <h1>পোস্টার / ব্যানার</h1>
  <a href="banner_form.php" class="btn">+ নতুন পোস্টার যুক্ত করুন</a>
</div>

<?php if (isset($_GET['deleted'])): ?><div class="alert alert-success">পোস্টার মুছে ফেলা হয়েছে।</div><?php endif; ?>
<?php if (isset($_GET['saved'])): ?><div class="alert alert-success">পোস্টার সংরক্ষণ করা হয়েছে।</div><?php endif; ?>

<div class="card-box">
  <table>
    <thead><tr><th>ছবি</th><th>শিরোনাম</th><th>ক্রম</th><th></th></tr></thead>
    <tbody>
      <?php if ($banners->num_rows === 0): ?>
        <tr><td colspan="4" style="text-align:center; padding:30px; color:#5E6D64;">এখনো কোনো পোস্টার যুক্ত করা হয়নি। হোমপেজের স্লাইডারে দেখাতে পোস্টার যুক্ত করুন।</td></tr>
      <?php endif; ?>
      <?php while ($b = $banners->fetch_assoc()): ?>
      <tr>
        <td><img src="<?php echo banner_image_url($b['image']); ?>" class="thumb" style="width:80px; height:44px;"></td>
        <td><?php echo e($b['title'] ?? '—'); ?></td>
        <td><?php echo (int)$b['sort_order']; ?></td>
        <td>
          <a href="banner_delete.php?id=<?php echo $b['id']; ?>" class="btn btn-danger" style="padding:6px 12px;" onclick="return confirm('পোস্টারটি ডিলিট করবেন?');">ডিলিট</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
