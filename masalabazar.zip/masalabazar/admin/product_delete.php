<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $stmt = $conn->prepare("SELECT image FROM products WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $p = $stmt->get_result()->fetch_assoc();
    if ($p) {
        delete_image($p['image'], UPLOAD_PRODUCT_DIR);
        $del = $conn->prepare("DELETE FROM products WHERE id=?");
        $del->bind_param('i', $id);
        $del->execute();
    }
}
redirect('products.php?deleted=1');
