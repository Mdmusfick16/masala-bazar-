<?php
$page_title = 'পণ্য ফর্ম';
require_once __DIR__ . '/includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$product = ['id'=>0,'name'=>'','description'=>'','price'=>'','unit'=>'পিস','stock_qty'=>'','category_id'=>'','image'=>'','status'=>'active'];
$error = '';

if ($id > 0) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $found = $stmt->get_result()->fetch_assoc();
    if ($found) $product = $found;
}

$categories = $conn->query("SELECT * FROM categories ORDER BY name ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $unit = trim($_POST['unit'] ?? 'পিস');
    $stock_qty = (int)($_POST['stock_qty'] ?? 0);
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
    $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';

    if ($name === '' || $price <= 0) {
        $error = 'পণ্যের নাম ও সঠিক দাম দিতে হবে।';
    } else {
        $image = $product['image'];
        $uploaded = handle_image_upload('image', UPLOAD_PRODUCT_DIR);
        if ($uploaded === false) {
            $error = 'ছবি আপলোডে সমস্যা হয়েছে। JPG/PNG/WEBP, সর্বোচ্চ 5MB সাইজের ছবি দিন।';
        } else {
            if ($uploaded) {
                delete_image($product['image'], UPLOAD_PRODUCT_DIR);
                $image = $uploaded;
            }

            if ($id > 0) {
                $stmt = $conn->prepare("UPDATE products SET name=?, description=?, price=?, unit=?, stock_qty=?, category_id=?, image=?, status=? WHERE id=?");
                $stmt->bind_param('ssdsiissi', $name, $description, $price, $unit, $stock_qty, $category_id, $image, $status, $id);
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("INSERT INTO products (name, description, price, unit, stock_qty, category_id, image, status) VALUES (?,?,?,?,?,?,?,?)");
                $stmt->bind_param('ssdsiiss', $name, $description, $price, $unit, $stock_qty, $category_id, $image, $status);
                $stmt->execute();
            }
            redirect('products.php?saved=1');
        }
    }
}
?>

<div class="topbar"><h1><?php echo $id > 0 ? 'পণ্য এডিট করুন' : 'নতুন পণ্য যুক্ত করুন'; ?></h1></div>

<?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>

<div class="card-box">
  <form method="post" enctype="multipart/form-data">
    <div class="form-grid">
      <div class="field">
        <label>পণ্যের নাম *</label>
        <input type="text" name="name" required value="<?php echo e($_POST['name'] ?? $product['name']); ?>" placeholder="যেমন: মিনিকেট চাল">
      </div>
      <div class="field">
        <label>ক্যাটাগরি</label>
        <select name="category_id">
          <option value="">-- নির্বাচন করুন --</option>
          <?php while ($c = $categories->fetch_assoc()): ?>
            <option value="<?php echo $c['id']; ?>" <?php echo (int)$product['category_id']===(int)$c['id']?'selected':''; ?>><?php echo e($c['name']); ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="field">
        <label>দাম (৳) *</label>
        <input type="number" step="0.01" name="price" required value="<?php echo e($_POST['price'] ?? $product['price']); ?>">
      </div>
      <div class="field">
        <label>একক (যেমন: কেজি, লিটার, পিস, প্যাকেট)</label>
        <input type="text" name="unit" value="<?php echo e($_POST['unit'] ?? $product['unit']); ?>">
      </div>
      <div class="field">
        <label>স্টক পরিমাণ</label>
        <input type="number" name="stock_qty" value="<?php echo e($_POST['stock_qty'] ?? $product['stock_qty']); ?>">
      </div>
      <div class="field">
        <label>স্ট্যাটাস</label>
        <select name="status">
          <option value="active" <?php echo $product['status']==='active'?'selected':''; ?>>একটিভ (সাইটে দেখাবে)</option>
          <option value="inactive" <?php echo $product['status']==='inactive'?'selected':''; ?>>ইনএকটিভ (সাইটে দেখাবে না)</option>
        </select>
      </div>
    </div>

    <div class="field">
      <label>বিবরণ</label>
      <textarea name="description" rows="3"><?php echo e($_POST['description'] ?? $product['description']); ?></textarea>
    </div>

    <div class="field">
      <label>পণ্যের ছবি <?php echo $id>0 ? '(পরিবর্তন করতে চাইলে নতুন ছবি দিন)' : ''; ?></label>
      <?php if ($product['image']): ?><img src="<?php echo product_image_url($product['image']); ?>" style="width:80px; height:80px; object-fit:cover; border-radius:8px; margin-bottom:8px;"><?php endif; ?>
      <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
    </div>

    <button type="submit" class="btn">💾 সংরক্ষণ করুন</button>
    <a href="products.php" class="btn btn-outline">বাতিল</a>
  </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
