<?php
$page_title = 'নতুন পোস্টার';
require_once __DIR__ . '/includes/header.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $sort_order = (int)($_POST['sort_order'] ?? 0);

    $uploaded = handle_image_upload('image', UPLOAD_BANNER_DIR);
    if (empty($uploaded)) {
        $error = 'দয়া করে একটি পোস্টার ছবি আপলোড করুন (JPG/PNG/WEBP, সর্বোচ্চ 5MB)।';
    } else {
        $stmt = $conn->prepare("INSERT INTO banners (title, image, sort_order) VALUES (?,?,?)");
        $stmt->bind_param('ssi', $title, $uploaded, $sort_order);
        $stmt->execute();
        redirect('banners.php?saved=1');
    }
}
?>

<div class="topbar"><h1>নতুন পোস্টার যুক্ত করুন</h1></div>

<?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>

<div class="card-box" style="max-width:600px;">
  <form method="post" enctype="multipart/form-data">
    <div class="field">
      <label>পোস্টার শিরোনাম (ঐচ্ছিক)</label>
      <input type="text" name="title" placeholder="যেমন: ঈদ স্পেশাল অফার - ২০% ছাড়">
    </div>
    <div class="field">
      <label>ক্রম নম্বর (ছোট নম্বর আগে দেখাবে)</label>
      <input type="number" name="sort_order" value="0">
    </div>
    <div class="field">
      <label>পোস্টার ছবি * <small style="color:#5E6D64;">(সুপারিশ: 1600×700 পিক্সেল)</small></label>
      <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp" required>
    </div>
    <button type="submit" class="btn">💾 সংরক্ষণ করুন</button>
    <a href="banners.php" class="btn btn-outline">বাতিল</a>
  </form>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
