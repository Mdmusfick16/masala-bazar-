<?php
$page_title = 'অর্ডার তালিকা';
require_once __DIR__ . '/includes/header.php';

$status_filter = $_GET['status'] ?? '';
$sql = "SELECT * FROM orders";
if (in_array($status_filter, ['pending','processing','completed','cancelled'])) {
    $sql .= " WHERE status='" . $conn->real_escape_string($status_filter) . "'";
}
$sql .= " ORDER BY created_at DESC";
$orders = $conn->query($sql);
?>

<div class="topbar"><h1>অর্ডার তালিকা</h1></div>

<div style="margin-bottom:16px; display:flex; gap:8px;">
  <a href="orders.php" class="btn <?php echo $status_filter===''?'':'btn-outline'; ?>">সব</a>
  <a href="orders.php?status=pending" class="btn <?php echo $status_filter==='pending'?'':'btn-outline'; ?>">পেন্ডিং</a>
  <a href="orders.php?status=processing" class="btn <?php echo $status_filter==='processing'?'':'btn-outline'; ?>">প্রসেসিং</a>
  <a href="orders.php?status=completed" class="btn <?php echo $status_filter==='completed'?'':'btn-outline'; ?>">সম্পন্ন</a>
  <a href="orders.php?status=cancelled" class="btn <?php echo $status_filter==='cancelled'?'':'btn-outline'; ?>">বাতিল</a>
</div>

<div class="card-box">
  <table>
    <thead><tr><th>#</th><th>কাস্টমার</th><th>ফোন</th><th>ঠিকানা</th><th>মোট</th><th>স্ট্যাটাস</th><th>তারিখ</th><th></th></tr></thead>
    <tbody>
      <?php if ($orders->num_rows === 0): ?>
        <tr><td colspan="8" style="text-align:center; padding:30px; color:#5E6D64;">কোনো অর্ডার পাওয়া যায়নি।</td></tr>
      <?php endif; ?>
      <?php while ($o = $orders->fetch_assoc()): ?>
      <tr>
        <td>#<?php echo $o['id']; ?></td>
        <td><?php echo e($o['customer_name']); ?></td>
        <td><?php echo e($o['phone']); ?></td>
        <td style="max-width:220px;"><?php echo e(mb_substr($o['address'],0,40)); ?><?php echo mb_strlen($o['address'])>40?'...':''; ?></td>
        <td><?php echo taka($o['total_amount']); ?></td>
        <td><span class="badge badge-<?php echo $o['status']; ?>"><?php echo e($o['status']); ?></span></td>
        <td><?php echo date('d M, h:i A', strtotime($o['created_at'])); ?></td>
        <td><a href="order_detail.php?id=<?php echo $o['id']; ?>" class="btn btn-outline">দেখুন</a></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
