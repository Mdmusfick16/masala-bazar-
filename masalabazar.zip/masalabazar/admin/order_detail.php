<?php
$page_title = 'অর্ডার বিস্তারিত';
require_once __DIR__ . '/includes/header.php';

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'] ?? 'pending';
    if (in_array($status, ['pending','processing','completed','cancelled'])) {
        $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
        $stmt->bind_param('si', $status, $id);
        $stmt->execute();
    }
    redirect('order_detail.php?id=' . $id . '&updated=1');
}

$stmt = $conn->prepare("SELECT * FROM orders WHERE id=?");
$stmt->bind_param('i', $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    echo '<div class="alert alert-error">অর্ডারটি পাওয়া যায়নি।</div>';
    require_once __DIR__ . '/includes/footer.php';
    exit;
}

$stmt2 = $conn->prepare("SELECT * FROM order_items WHERE order_id=?");
$stmt2->bind_param('i', $id);
$stmt2->execute();
$items = $stmt2->get_result();
?>

<div class="topbar">
  <h1>অর্ডার #<?php echo $order['id']; ?></h1>
  <a href="orders.php" class="btn btn-outline">← তালিকায় ফিরুন</a>
</div>

<?php if (isset($_GET['updated'])): ?><div class="alert alert-success">স্ট্যাটাস আপডেট করা হয়েছে।</div><?php endif; ?>

<div class="form-grid">
  <div class="card-box">
    <h3 style="margin-top:0;">কাস্টমার তথ্য</h3>
    <p><b>নাম:</b> <?php echo e($order['customer_name']); ?></p>
    <p><b>ফোন:</b> <a href="tel:<?php echo e($order['phone']); ?>"><?php echo e($order['phone']); ?></a></p>
    <p><b>ঠিকানা:</b> <?php echo nl2br(e($order['address'])); ?></p>
    <?php if ($order['note']): ?><p><b>নির্দেশনা:</b> <?php echo nl2br(e($order['note'])); ?></p><?php endif; ?>
    <p><b>অর্ডারের সময়:</b> <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></p>

    <form method="post" style="margin-top:16px;">
      <label>অর্ডার স্ট্যাটাস</label>
      <select name="status">
        <?php foreach (['pending'=>'পেন্ডিং','processing'=>'প্রসেসিং','completed'=>'সম্পন্ন','cancelled'=>'বাতিল'] as $val=>$label): ?>
          <option value="<?php echo $val; ?>" <?php echo $order['status']===$val?'selected':''; ?>><?php echo $label; ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn" style="margin-top:12px;">আপডেট করুন</button>
    </form>
  </div>

  <div class="card-box">
    <h3 style="margin-top:0;">পণ্যের তালিকা</h3>
    <table>
      <thead><tr><th>পণ্য</th><th>দাম</th><th>পরিমাণ</th><th>সাবটোটাল</th></tr></thead>
      <tbody>
        <?php while ($it = $items->fetch_assoc()): ?>
        <tr>
          <td><?php echo e($it['product_name']); ?></td>
          <td><?php echo taka($it['price']); ?></td>
          <td><?php echo $it['qty']; ?></td>
          <td><?php echo taka($it['subtotal']); ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <div style="text-align:right; font-size:18px; font-weight:700; color:var(--dark-green); margin-top:14px;">
      সর্বমোট: <?php echo taka($order['total_amount']); ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
