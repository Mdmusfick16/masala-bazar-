<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';

if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT * FROM admins WHERE username=?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        redirect('index.php');
    } else {
        $error = 'ইউজারনেম বা পাসওয়ার্ড ভুল হয়েছে।';
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>এডমিন লগইন - MasalaBazar</title>
<link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
<div class="login-wrap">
  <div class="login-box">
    <h2>🛒 MasalaBazar<br><small style="font-size:14px; color:#5E6D64;">এডমিন প্যানেল</small></h2>
    <?php if ($error): ?><div class="alert alert-error"><?php echo e($error); ?></div><?php endif; ?>
    <form method="post">
      <div class="field"><label>ইউজারনেম</label><input type="text" name="username" required autofocus></div>
      <div class="field"><label>পাসওয়ার্ড</label><input type="password" name="password" required></div>
      <button type="submit" class="btn" style="width:100%;">লগইন করুন</button>
    </form>
  </div>
</div>
</body>
</html>
