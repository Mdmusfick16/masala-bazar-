<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../includes/functions.php';
require_login();
$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? e($page_title) . ' - এডমিন' : 'এডমিন প্যানেল'; ?></title>
<link rel="stylesheet" href="assets/css/admin.css">
</head>
<body>
<div class="wrap">
  <div class="sidebar">
    <div class="logo">🛒 MasalaBazar</div>
    <a href="index.php" class="nav-link <?php echo $current==='index.php'?'active':''; ?>">📊 ড্যাশবোর্ড</a>
    <a href="products.php" class="nav-link <?php echo in_array($current,['products.php','product_form.php'])?'active':''; ?>">📦 পণ্য</a>
    <a href="orders.php" class="nav-link <?php echo in_array($current,['orders.php','order_detail.php'])?'active':''; ?>">🧾 অর্ডার</a>
    <a href="banners.php" class="nav-link <?php echo in_array($current,['banners.php','banner_form.php'])?'active':''; ?>">🖼️ পোস্টার/ব্যানার</a>
    <a href="../index.php" target="_blank" class="nav-link">🌐 সাইট দেখুন</a>
    <a href="logout.php" class="nav-link">🚪 লগআউট</a>
  </div>
  <div class="main">
