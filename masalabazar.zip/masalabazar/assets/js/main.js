document.addEventListener('DOMContentLoaded', function () {

  // ===== Hero slider =====
  const track = document.getElementById('heroTrack');
  const dotsWrap = document.getElementById('heroDots');
  if (track) {
    const slides = track.children.length;
    let idx = 0;
    for (let i = 0; i < slides; i++) {
      const d = document.createElement('button');
      if (i === 0) d.classList.add('active');
      d.addEventListener('click', () => goTo(i));
      dotsWrap.appendChild(d);
    }
    function goTo(i) {
      idx = i;
      track.style.transform = `translateX(-${idx * 100}%)`;
      [...dotsWrap.children].forEach((d, di) => d.classList.toggle('active', di === idx));
    }
    if (slides > 1) {
      setInterval(() => { goTo((idx + 1) % slides); }, 4500);
    }
  }

  // ===== Qty steppers on product cards =====
  document.querySelectorAll('.add-to-cart-form').forEach(form => {
    const input = form.querySelector('.qty-input');
    form.querySelector('.qty-plus').addEventListener('click', () => {
      input.value = Math.min(parseInt(input.value || 1) + 1, parseInt(input.max || 999));
    });
    form.querySelector('.qty-minus').addEventListener('click', () => {
      input.value = Math.max(parseInt(input.value || 1) - 1, 1);
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const productId = form.dataset.id;
      const qty = input.value;
      fetch('cart_action.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=add&product_id=${productId}&qty=${qty}`
      })
      .then(r => r.json())
      .then(data => {
        if (data.ok) {
          showToast(data.message || 'কার্টে যোগ হয়েছে');
          document.querySelectorAll('.cart-pill .count').forEach(el => el.textContent = data.cart_count);
        } else {
          showToast(data.message || 'সমস্যা হয়েছে', true);
        }
      });
    });
  });

  function showToast(msg, isError) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = (isError ? '⚠️ ' : '✅ ') + msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2200);
  }
});
